<?php


function launcher_bootstaping(){
  load_theme_textdomain('launcher');
  add_theme_support('post-thumbnails');
  add_theme_support('title-tag');
  register_nav_menu( "footerleft", __('Footer Left'));
}
add_action('after_setup_theme','launcher_bootstaping');


function launcher_assets(){
  wp_enqueue_style('animate_css', get_theme_file_uri("/assets/css/animate.css"));
  wp_enqueue_style('icomoon_css', get_theme_file_uri("/assets/css/icomoon.css"));
  wp_enqueue_style('bootstrap_css', get_theme_file_uri("/assets/css/bootstrap.css"));
  wp_enqueue_style('style_css', get_theme_file_uri("/assets/css/style.css"));
  wp_enqueue_style('style', get_stylesheet_uri());

  wp_enqueue_script('easing_js', get_theme_file_uri('/assets/js/jquery.easing.1.3.js'),array('jquery'),null,true);
  wp_enqueue_script('bootstrap_js', get_theme_file_uri('/assets/js/bootstrap.min.js'),array('jquery'),null,true);
  wp_enqueue_script('waypoints_js', get_theme_file_uri('/assets/js/jquery.waypoints.min.js'),array('jquery'),null,true);
  wp_enqueue_script('simpleCountdown_js', get_theme_file_uri('/assets/js/simplyCountdown.js'),array('jquery'),null,true);
  wp_enqueue_script('main_js', get_theme_file_uri('/assets/js/main.js'),array('jquery'),null,true);

  $year = get_post_meta(get_the_ID(),"year",true);
  $month = get_post_meta(get_the_ID(),"month",true);
  $day = get_post_meta(get_the_ID(),"day",true);

  wp_localize_script('main_js','datadata',array(
    'year' => $year,
    'month' => $month,
    'day' => $day,
  ));
}
add_action('wp_enqueue_scripts', 'launcher_assets');


function launcher_footer_sidebar(){
register_sidebar(
  array(
      'id'            => 'footer_right',
      'name'          => __( 'Footer right Sidebar' ),
      'description'   => __( 'Footer right Sidebar.' ),
      'before_widget' => '<div id="%1$s" class=" text-right widget %2$s">',
      'after_widget'  => '</div>',
      'before_title'  => '<h3 class="widget-title">',
      'after_title'   => '</h3>',
  )
);
}
add_action('widgets_init','launcher_footer_sidebar');



function extra_design_bg(){
  if(is_page()){
    ?>
    <style>
      .bg-image{
        background-image: url(<?php echo get_the_post_thumbnail_url(); ?>);
      }

    </style>
  <?php
  }
}
add_action('wp_head','extra_design_bg');

function nav_menu_class( $classes , $item ){
  $classes[]= 'list-inline-item';
  return $classes;
}
add_filter('nav_menu_css_class','nav_menu_class',10,2);